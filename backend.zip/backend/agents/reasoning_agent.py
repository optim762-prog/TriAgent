import os
import json
from groq import Groq
from openai import OpenAI
from models.schemas import ReasoningStep

CONFIDENCE_THRESHOLD = 0.6
DEFAULT_MODEL = "llama-3.3-70b-versatile"
GROQ_MODELS = ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768"]

def get_client(model: str):
    if model in GROQ_MODELS:
        return Groq(api_key=os.getenv("GROQ_API_KEY"))
    return OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# the agent always responds in JSON — easier to parse and less hallucination-prone
SYSTEM_PROMPT = """You are an expert agricultural process reasoning agent.
You receive a structured process rule and must follow it step by step.

At each step:
1. THINK about the current state and what comes next
2. ACT by deciding what tool or action is needed
3. OBSERVE the result before moving to the next step

For each <<decision>> gateway, pick the right branch and rate your confidence (0 to 1).
If confidence < {threshold}, flag for human review instead of guessing.

Always reply with this exact JSON:
{{
  "step": <int>,
  "thought": "<reasoning>",
  "action": "<what to do or null>",
  "gateway_decision": "<yes/no/null>",
  "confidence": <0.0-1.0>,
  "process_complete": <bool>,
  "requires_tool": <bool>,
  "tool_name": "<name or null>",
  "tool_params": {{}},
  "diagnosis": "<final diagnosis or null>",
  "treatment": "<recommendation or null>"
}}"""


class ReasoningAgent:

    def __init__(self, model: str = DEFAULT_MODEL):
        self.model = model
        self.client = get_client(model)
        self.total_tokens = 0
        self.confidence_threshold = CONFIDENCE_THRESHOLD

    def run(self, process_rule: str, input_description: str, context: dict = {}) -> dict:
        reasoning_trace = []
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT.format(threshold=self.confidence_threshold)},
            {"role": "user", "content": f"Process Rule:\n{process_rule}\n\nSituation:\n{input_description}\n\nContext:\n{json.dumps(context, indent=2)}\n\nStart executing the rule."}
        ]
        diagnosis = None
        treatment = None
        escalated = False
        actions_taken = []

        for step_num in range(1, 20):
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.0,
                response_format={"type": "json_object"}
            )
            self.total_tokens += resp.usage.total_tokens
            raw = resp.choices[0].message.content

            try:
                step_data = json.loads(raw)
            except json.JSONDecodeError:
                break

            step = ReasoningStep(
                step=step_num,
                thought=step_data.get("thought", ""),
                action=step_data.get("action"),
                observation=None,
                confidence=step_data.get("confidence", 1.0),
                gateway_decision=step_data.get("gateway_decision")
            )

            # bail out if not confident enough
            if step_data.get("confidence", 1.0) < self.confidence_threshold:
                escalated = True
                step.observation = "low confidence — escalated to human"
                reasoning_trace.append(step)
                break

            if step_data.get("diagnosis"):
                diagnosis = step_data["diagnosis"]
            if step_data.get("treatment"):
                treatment = step_data["treatment"]
            if step_data.get("action"):
                actions_taken.append(step_data["action"])

            reasoning_trace.append(step)

            if step_data.get("process_complete"):
                break

            # hand off to execution agent if a tool is needed
            if step_data.get("requires_tool"):
                return {
                    "status": "tool_required",
                    "tool_name": step_data.get("tool_name"),
                    "tool_params": step_data.get("tool_params", {}),
                    "reasoning_trace": reasoning_trace,
                    "process_state": {},
                    "messages": messages,
                    "step_data": step_data,
                    "diagnosis": diagnosis,
                    "treatment": treatment,
                    "actions_taken": actions_taken,
                    "escalated": escalated
                }

            messages.append({"role": "assistant", "content": raw})
            messages.append({"role": "user", "content": "Continue to the next step."})

        return {
            "status": "complete" if not escalated else "escalated",
            "reasoning_trace": reasoning_trace,
            "diagnosis": diagnosis,
            "treatment": treatment,
            "actions_taken": actions_taken,
            "hallucination_flags": [],
            "escalated": escalated
        }

    def resume_after_tool(self, messages, tool_name, tool_result,
                          reasoning_trace, process_state,
                          diagnosis, treatment, actions_taken, escalated) -> dict:
        # inject the tool result and keep going
        messages.append({"role": "user", "content": f"'{tool_name}' returned: {tool_result}\nContinue."})
        if reasoning_trace:
            reasoning_trace[-1].observation = tool_result

        for step_num in range(len(reasoning_trace) + 1, 20):
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.0,
                response_format={"type": "json_object"}
            )
            self.total_tokens += resp.usage.total_tokens
            raw = resp.choices[0].message.content

            try:
                step_data = json.loads(raw)
            except json.JSONDecodeError:
                break

            step = ReasoningStep(
                step=step_num,
                thought=step_data.get("thought", ""),
                action=step_data.get("action"),
                observation=None,
                confidence=step_data.get("confidence", 1.0),
                gateway_decision=step_data.get("gateway_decision")
            )

            if step_data.get("confidence", 1.0) < self.confidence_threshold:
                escalated = True
                reasoning_trace.append(step)
                break

            if step_data.get("diagnosis"):
                diagnosis = step_data["diagnosis"]
            if step_data.get("treatment"):
                treatment = step_data["treatment"]
            if step_data.get("action"):
                actions_taken.append(step_data["action"])

            reasoning_trace.append(step)

            if step_data.get("process_complete"):
                break

            if step_data.get("requires_tool"):
                return {
                    "status": "tool_required",
                    "tool_name": step_data.get("tool_name"),
                    "tool_params": step_data.get("tool_params", {}),
                    "reasoning_trace": reasoning_trace,
                    "process_state": process_state,
                    "messages": messages,
                    "step_data": step_data,
                    "diagnosis": diagnosis,
                    "treatment": treatment,
                    "actions_taken": actions_taken,
                    "escalated": escalated
                }

            messages.append({"role": "assistant", "content": raw})
            messages.append({"role": "user", "content": "Next step."})

        return {
            "status": "complete" if not escalated else "escalated",
            "reasoning_trace": reasoning_trace,
            "diagnosis": diagnosis,
            "treatment": treatment,
            "actions_taken": actions_taken,
            "hallucination_flags": [],
            "escalated": escalated
        }
